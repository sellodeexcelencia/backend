import template from './tmppostulate.html'
import './tmppostulate.styl'

const tmppostulateComponent = {
  template
}

export default tmppostulateComponent
