import controller from './profileEntity.controller'
import template from './profileEntity.html'
import './profileEntity.styl'

const profileEntityComponent = {
  controller,
  template
}

export default profileEntityComponent