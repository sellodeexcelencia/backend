import template from './landingPage.html'

const homeComponent = {
  template
}

export default homeComponent
