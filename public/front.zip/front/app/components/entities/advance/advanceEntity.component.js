import controller from './advanceEntity.controller'
import template from './advanceEntity.html'
import './advanceEntity.styl'

const advanceEntityComponent = {
  controller,
  template
}

export default advanceEntityComponent