import controller from './learnEvaluator.controller'
import template from './learnEvaluator.html'
import './learnEvaluator.styl'

const learnEvaluatorComponent = {
  controller,
  template
}

export default learnEvaluatorComponent