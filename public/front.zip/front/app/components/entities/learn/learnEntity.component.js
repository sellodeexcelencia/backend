import controller from './learnEntity.controller'
import template from './learnEntity.html'
import './learnEntity.styl'

const learnEntityComponent = {
  controller,
  template
}

export default learnEntityComponent