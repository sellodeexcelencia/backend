import controller from './activityEvaluator.controller'
import template from './activityEvaluator.html'
import './activityEvaluator.styl'

const activityEvaluatorComponent = {
  controller,
  template
}

export default activityEvaluatorComponent