import template from './activeAccount.html'

const activeAccountComponent = {
  template,
  bindings: {
    user: '<'
  }
}

export default activeAccountComponent