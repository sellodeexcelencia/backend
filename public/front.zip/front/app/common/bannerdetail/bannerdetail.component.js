import template from './bannerdetail.html'
import controller from './bannerdetail.controller'
import './bannerdetail.styl'

const bannerDetailComponent = {
  template,
  controller
}

export default bannerDetailComponent
