import template from './moreInformation.html'
import './moreInformation.styl'

const moreInformationComponent = {
  template
}

export default moreInformationComponent
