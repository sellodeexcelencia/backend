import template from './servicelist.html'
import controller from './servicelist.controller'
import './servicelist.styl'

const servicelistComponent = {
  template,
  controller
}

export default servicelistComponent