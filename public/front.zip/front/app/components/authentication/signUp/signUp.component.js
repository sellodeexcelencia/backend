import template from './signUp.html'
import controller from './signUp.controller'
import './signUp.styl'

const signUpComponent = {
  template,
  controller,
}

export default signUpComponent
