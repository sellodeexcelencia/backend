import template from './commentitem.html'
import './commentitem.styl'

const commentItemComponent = {
  template,
  bindings:{
    item : '<'
  }
}

export default commentItemComponent