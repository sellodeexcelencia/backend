import template from './slider.html'
import './slider.styl'
import controller from './slider.controller'

const sliderComponent = {
  template,
  controller
}

export default sliderComponent
