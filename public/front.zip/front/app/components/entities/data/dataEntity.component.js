import controller from './dataEntity.controller'
import template from './dataEntity.html'
import './dataEntity.styl'

const dataEntityController = {
  template,
  controller
}

export default dataEntityController