import controller from './activityEntity.controller'
import template from './activityEntity.html'
import './activityEntity.styl'

const activityEntityComponent = {
  controller,
  template
}

export default activityEntityComponent