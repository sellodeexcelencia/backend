import controller from './advanceEvaluator.controller'
import template from './advanceEvaluator.html'
import './advanceEvaluator.styl'

const advanceEvaluatorComponent = {
  controller,
  template
}

export default advanceEvaluatorComponent