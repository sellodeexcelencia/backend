import template from './changePwd.html'
import controller from './changePwd.controller'

const changePwdComponent = {
  template,
  controller
}

export default changePwdComponent
