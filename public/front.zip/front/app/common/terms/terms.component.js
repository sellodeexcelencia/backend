import template from './terms.html'
import './terms.styl'

const termsComponent = {
  template
}

export default termsComponent
