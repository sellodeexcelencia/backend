import controller from './profileEvaluator.controller'
import template from './profileEvaluator.html'
import './profileEvaluator.styl'

const profileEvaluatorComponent = {
  controller,
  template
}

export default profileEvaluatorComponent