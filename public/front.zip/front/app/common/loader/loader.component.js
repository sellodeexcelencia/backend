import template from './loader.html'

const loaderComponent = {
  template,
  bindings: {
    size: '@'
  }
}

export default loaderComponent