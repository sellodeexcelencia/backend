import template from './servicedetail.html'
import controller from './servicedetail.controller'
import './servicedetail.styl'

const servicedetailComponent = {
  template,
  controller
}

export default servicedetailComponent