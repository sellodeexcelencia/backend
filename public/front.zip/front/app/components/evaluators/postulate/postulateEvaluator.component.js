import controller from './postulateEvaluator.controller'
import template from './postulateEvaluator.html'
import './postulateEvaluator.styl'

const postulateEvaluatorComponent = {
  controller,
  template
}

export default postulateEvaluatorComponent