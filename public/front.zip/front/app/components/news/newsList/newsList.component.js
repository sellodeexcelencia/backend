import template from './newsList.html'
import controller from './newList.controller'
import './newList.styl'

const newsListComponent = {
  template,
  controller
}

export default newsListComponent
