import template from './announcementTable.html'
import controller from './announcementTable.controller'

const announcementTableComponent = {
  template,
  controller
}

export default announcementTableComponent
