import template from './footer.html'
import controller from './footer.controller'
import './footer.styl'

const footerComponent = {
  template,
  controller
}

export default footerComponent
