import template from './signIn.html'
import controller from './signIn.controller'
import './signIn.styl'

const signInComponent = {
  template,
  controller
}

export default signInComponent
