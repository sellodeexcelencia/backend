import template from './embed.html'
import controller from './embed.controller'
import './embed.styl'

const embedComponent = {
  template,
  controller
}

export default embedComponent