import template from './newRow.html'

const newRowComponent = {
  template,
  bindings: {
    new: '<'
  }
}

export default newRowComponent
