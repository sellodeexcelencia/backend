import template from './fameList.html'
import controller from './fameList.controller'
import './fameList.styl'

const fameListComponent = {
  template,
  controller
}

export default fameListComponent
