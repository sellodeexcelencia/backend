import controller from './dataEvaluator.controller'
import template from './dataEvaluator.html'
import './dataEvaluator.styl'

const dataEvaluatorController = {
  template,
  controller
}

export default dataEvaluatorController