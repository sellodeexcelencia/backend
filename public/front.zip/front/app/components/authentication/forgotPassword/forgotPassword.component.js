import template from './forgotPassword.html'
import controller from './forgotPassword.controller'

const forgotPasswordComponent = {
  controller,
  template
}

export default forgotPasswordComponent
