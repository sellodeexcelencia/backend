import template from './registerEntity.html'
import controller from './registerEntity.controller'
import './registerEntity.styl'

const registerEntityComponent = {
  template,
  controller
}

export default registerEntityComponent
