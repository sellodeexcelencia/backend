import template from './activityList.html'
import controller from './activityList.controller'

const activityListComponent = {
  template,
  controller
}

export default activityListComponent