import template from './registerEvaluator.html'
import controller from './registerEvaluators.controller'
import './registerEvaluators.styl'

const registerEvaluatorComponent = {
  template,
  controller
}

export default registerEvaluatorComponent
